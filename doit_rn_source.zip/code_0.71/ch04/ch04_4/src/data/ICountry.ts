export type ICountry = {
  region: string
  subregion: string
  name: string
  population: number
}
